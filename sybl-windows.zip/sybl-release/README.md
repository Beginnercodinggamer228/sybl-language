# SyBL - Symbol Programming Language

## 🚀 Quick Setup

1. **Install:** Double-click `install.reg`
2. **Test:** Double-click `examples/hello.syb`
3. **Code:** Create your own `.syb` files

## ✨ Example

Create `test.syb`:
```sybl
>_ "Hello, World!"
name =#= "Programmer"
>_ "Hello, $%name%!"
```

Double-click `test.syb` to run!

## 📖 Syntax

- `>_ "text"` - Print text
- `var =$= 42` - Integer
- `var =$.$= 3.14` - Float  
- `var =#= "text"` - String
- `var =&= +` - Boolean
- `?(condition)?` ... `?end?` - If
- `@(counter < 5)@` ... `@end@` - Loop

## 🎨 VS Code Extension

Search "SyBL Symbol Programming Language" for syntax highlighting.

---

**Now all `.syb` files run with double-click!** 🎉